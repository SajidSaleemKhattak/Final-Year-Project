import React, { useState } from "react";
import logo from "../../assets/home/logo.png";
import gear from "../../assets/Client/Gear.png";
import Vector from "../../assets/Client/Vector.png";
import pfp from "../../assets/Client/pfp.png";
import Sidebar from "../../pages/client/components/C-LSidebar"; // Imported Sidebar
import { Link } from "react-router-dom";
import { FaStar } from "react-icons/fa";
import { FaRegHeart } from "react-icons/fa6";
import { IoMdNotificationsOutline } from "react-icons/io";

const Categories = () => {
  let [showNotification, setshowNotification] = useState(false);

  const handleNotification = () => {
    {
      setshowNotification((toggle) => !toggle);
    }
  };
  const active = "home";
  const array_Lawyers = [
    { img: pfp, name: "Danish", type: "CivilCriminal", rating: 4 },
    { img: pfp, name: "Danish", type: "CivilCriminal", rating: 4 },
    { img: pfp, name: "Danish", type: "CivilCriminal", rating: 4 },
    { img: pfp, name: "Danish", type: "CivilCriminal", rating: 4 },
    { img: pfp, name: "Danish", type: "CivilCriminal", rating: 4 },
    { img: pfp, name: "Danish", type: "CivilCriminal", rating: 4 },
    { img: pfp, name: "Danish", type: "CivilCriminal", rating: 4 },
    { img: pfp, name: "Danish", type: "CivilCriminal", rating: 4 },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* HEADER */}
      <div className="flex justify-between mx-20 mt-6">
        <img src={logo} alt="" className="w-[219px] h-[57px]" />

        <div className="flex justify-between relative gap-4 items-center">
          <img
            src={Vector}
            onClick={handleNotification}
            className="w-5 h-5 hover:scale-120 duration-150 cursor-pointer active:scale-110"
            alt=""
          />
          {showNotification && (
            <div className="absolute top-12 flex border-[#62B9CB] -left-3 justify-between gap-6 font-semibold z-50 border-2 rounded-xl py-4 pb-7 w-70 flex-col items-center   bg-white text-[#62B9CB]">
              <div className="flex justify-between px-6 bg-[#62B9CB]  w-full py-4 -mt-[17px] border-0 rounded-t-xl">
                <div className="text-xl text-white">Notifcations</div>
                <div className="text-white">
                  <IoMdNotificationsOutline size={30} />
                </div>
              </div>

              <div className="flex gap-4 justify-between items-center w-full px-6 ">
                <div>
                  <Link to="/appointments/completed">
                    <div className="text-lg underline underline-offset-6 hover:text-[black]">
                      Appointment Approved
                    </div>
                  </Link>{" "}
                </div>
                <div className="text-lg border-0 rounded-full bg-[#62B9CB] px-3 text-white ">
                  2
                </div>
              </div>
              <div className="flex gap-4 justify-between items-center w-full px-6 ">
                <div>
                  <Link to="/messages">
                    <div className="text-lg underline underline-offset-6 hover:text-[#62B9CB]">
                      New Messages
                    </div>
                  </Link>{" "}
                </div>
                <div className="text-lg border-0 rounded-full bg-[#62B9CB] px-3 text-white">
                  7
                </div>
              </div>
              <div className="flex gap-4 justify-between items-center w-full px-6">
                <div>
                  <Link to="/appointments">
                    <div className="text-lg underline underline-offset-6 hover:text-[#62B9CB]">
                      Appointment Pendings
                    </div>
                  </Link>{" "}
                </div>
                <div className="text-lg border-0 rounded-full bg-[#62B9CB] px-3 text-white">
                  3
                </div>
              </div>
            </div>
          )}

          <img src={gear} className="w-5 h-5" alt="" />
          <div className="flex justify-between gap-1.5">
            <img src={pfp} className="w-7 h-7 rounded-4xl" alt="" />
            <p className="text-neutral-600 font-semibold">Sajid Saleem</p>
          </div>
        </div>
      </div>
      <hr className="mt-4 border-neutral-200 border" />

      {/* MAIN CONTENT */}
      <div className="flex flex-grow">
        {/* SIDEBAR */}
        <Sidebar active={active} />

        {/* MAIN AREA */}
        <div className="w-full px-10 py-10">
          <p className="text-2xl font-semibold">Welcome Back Sajid</p>

          {/* Container Below Welcome Text */}
          <div className="border border-neutral-200 rounded-2xl py-10 px-10 mt-10">
            {/* Top Bar with Type and Search */}
            <div className="flex justify-between mb-5">
              <p className="text-xl">Civil Lawyers</p>
              <input
                className="border border-neutral-200 rounded-xl px-6 py-2"
                type="search"
                placeholder="Search for Category"
              />
            </div>

            {/* Lawyer Cards Grid */}
            <div className="grid grid-cols-4 gap-6">
              {array_Lawyers.map((element, index) => (
                <div
                  key={index}
                  className="flex flex-col border border-neutral-200 rounded-2xl px-4 py-4 items-center gap-2"
                >
                  <img
                    className="w-[45%] h-[45%] rounded-[400px] object-cover"
                    src={element.img}
                    alt="Lawyer Pfp"
                  />
                  <p className="font-semibold">{element.name}</p>
                  <p className="text-[13px] font-semibold text-[#62B9CB]">
                    {element.type}
                  </p>

                  {/* Star Rating */}
                  <div className="flex mb-2">
                    {[...Array(5)].map((_, i) => (
                      <FaStar
                        key={i}
                        className={`h-4 w-4 ${
                          i < element.rating
                            ? "text-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>

                  <Link to="/lawyer_check">
                    <button className="px-10 py-2 text-sm font-semibold bg-[#62B9CB] text-white rounded-lg">
                      Book Now
                    </button>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Categories;
