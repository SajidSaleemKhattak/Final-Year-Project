import React, { useState } from "react";
import logo from "../../assets/home/logo.png";
import tarazoImg from "../../assets/login/tarazo.png";
import { Link } from "react-router-dom";
import { FaFacebookF, FaTwitter } from "react-icons/fa";
import { FcGoogle } from "react-icons/fc";

const Client_Signup = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 min-h-screen">
      {/* Left Section */}
      <div className="flex flex-col px-6 md:px-10 py-8 justify-top bg-white">
        <div className="flex flex-col md:flex-row gap-8 w-screen md:w-full md:gap-2 justify-between items-center mb-6">
          <img src={logo} className="w-40 md:w-[219px] h-auto" alt="logo" />
          <Link to="/">
            <button className="px-6 py-2 text-sm md:text-base bg-[#62B9CB] rounded-3xl text-white">
              Back to Website
            </button>
          </Link>
        </div>

        <div className="flex flex-col items-center gap-5 -ml-3 md:ml-0 md:w-full w-screen">
          <p className="text-xl md:text-2xl font-semibold text-center text-[#62B9CB]">
            Welcome to Client's Portal
          </p>
          <p className="text-center text-gray-600 text-sm md:text-base max-w-md">
            Let’s get to know you a bit. Just the essentials to build better
            relation with you.
          </p>

          <input
            className="border border-gray-300 rounded-xl px-4 py-2 w-full max-w-md"
            type="text"
            placeholder="Enter Your Name"
          />
          <input
            className="border border-gray-300 rounded-xl px-4 py-2 w-full max-w-md"
            type="email"
            placeholder="Enter Your Email"
          />
          <input
            className="border border-gray-300 rounded-xl px-4 py-2 w-full max-w-md"
            type="password"
            placeholder="Enter Your Password"
          />
          <input
            className="border border-gray-300 rounded-xl px-4 py-2 w-full max-w-md"
            type="password"
            placeholder="Confirm Password"
          />

          <Link to="/additional_client" className="w-full max-w-md">
            <button className="w-full py-2 font-bold bg-[#62B9CB] rounded-3xl text-white">
              Signup
            </button>
          </Link>

          <div className="flex items-center gap-3 w-full max-w-md mt-4">
            <hr className="flex-grow border-gray-300" />
            <p className="text-sm text-gray-600">Or Login With</p>
            <hr className="flex-grow border-gray-300" />
          </div>

          <div className="flex justify-center gap-6 text-xl mt-2">
            <FaFacebookF className="text-blue-600 cursor-pointer hover:scale-110 transition" />
            <FcGoogle className="cursor-pointer hover:scale-110 transition" />
            <FaTwitter className="text-sky-400 cursor-pointer hover:scale-110 transition" />
          </div>

          <p className="mt-4 text-sm text-gray-600">
            Already Have an account?
            <Link to="/signup">
              <span className="text-[#62B9CB] ml-1 underline">Login</span>
            </Link>
          </p>
        </div>
      </div>

      {/* Right Section */}
      <div className="hidden md:block bg-violet-200 h-full">
        <img
          src={tarazoImg}
          className="w-full h-full object-cover"
          alt="Tarazo"
        />
      </div>
    </div>
  );
};

export default Client_Signup;
